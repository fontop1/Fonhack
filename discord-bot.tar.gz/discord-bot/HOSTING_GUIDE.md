# 🌐 دليل الاستضافة الشامل - تشغيل البوت 24/7

هذا الدليل يشرح جميع طرق استضافة البوت ليعمل 24 ساعة طوال الأسبوع.

---

## 📑 جدول المحتويات

1. [الاستضافة على VPS (الطريقة الموصى بها)](#1-الاستضافة-على-vps)
2. [الاستضافة باستخدام Docker](#2-الاستضافة-باستخدام-docker)
3. [الاستضافة على خدمات سحابية مجانية](#3-الاستضافة-على-خدمات-سحابية-مجانية)
4. [الاستضافة على جهازك الشخصي](#4-الاستضافة-على-جهازك-الشخصي)

---

## 1. الاستضافة على VPS

### أفضل مزودي VPS

| المزود | السعر الشهري | الذاكرة | المساحة | رابط التسجيل |
|--------|--------------|---------|---------|--------------|
| **DigitalOcean** | $4-6 | 512MB-1GB | 10-25GB | [digitalocean.com](https://www.digitalocean.com/) |
| **Linode** | $5 | 1GB | 25GB | [linode.com](https://www.linode.com/) |
| **Vultr** | $2.50-6 | 512MB-1GB | 10-25GB | [vultr.com](https://www.vultr.com/) |
| **AWS EC2** | مجاني لسنة | 1GB | 30GB | [aws.amazon.com](https://aws.amazon.com/free/) |
| **Oracle Cloud** | مجاني للأبد | 1GB | 50GB | [oracle.com/cloud/free](https://www.oracle.com/cloud/free/) |
| **Contabo** | €3.99 | 4GB | 50GB | [contabo.com](https://contabo.com/) |

### خطوات الإعداد على VPS

#### الخطوة 1: إنشاء VPS

1. سجل في أحد المزودين أعلاه
2. أنشئ VPS جديد باستخدام **Ubuntu 22.04 LTS**
3. احصل على عنوان IP الخاص بالسيرفر

#### الخطوة 2: الاتصال بالسيرفر

```bash
# من جهازك المحلي
ssh root@YOUR_SERVER_IP

# إذا طُلب منك، أدخل كلمة المرور المرسلة إلى بريدك
```

#### الخطوة 3: تحديث النظام

```bash
apt update && apt upgrade -y
```

#### الخطوة 4: تثبيت المتطلبات

```bash
# تثبيت Python و Git
apt install python3 python3-pip python3-venv git screen -y

# التحقق من الإصدار
python3 --version  # يجب أن يكون 3.8 أو أحدث
```

#### الخطوة 5: رفع ملفات البوت

**الطريقة 1: استخدام Git (إذا كان المشروع على GitHub)**

```bash
cd /root
git clone https://github.com/YOUR_USERNAME/discord-bot.git
cd discord-bot
```

**الطريقة 2: استخدام SCP (من جهازك المحلي)**

```bash
# من جهازك المحلي (ليس من السيرفر)
scp -r /path/to/discord-bot root@YOUR_SERVER_IP:/root/
```

**الطريقة 3: استخدام SFTP**

استخدم برنامج مثل [FileZilla](https://filezilla-project.org/) أو [WinSCP](https://winscp.net/)

#### الخطوة 6: إعداد البوت

```bash
cd /root/discord-bot

# إنشاء ملف .env
nano .env
```

أضف التوكن:
```
DISCORD_TOKEN=your_actual_token_here
```

احفظ بالضغط على `Ctrl+X` ثم `Y` ثم `Enter`

#### الخطوة 7: تثبيت المكتبات

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

#### الخطوة 8: تشغيل البوت

**الطريقة 1: باستخدام Screen (سريعة)**

```bash
# إنشاء جلسة screen
screen -S discord-bot

# تشغيل البوت
source venv/bin/activate
python bot.py

# للخروج من screen مع ترك البوت يعمل:
# اضغط Ctrl+A ثم اضغط D

# للعودة إلى الجلسة لاحقاً:
screen -r discord-bot

# لإيقاف البوت:
# ارجع إلى الجلسة واضغط Ctrl+C
```

**الطريقة 2: باستخدام systemd (موصى بها للإنتاج)**

```bash
# نسخ ملف الخدمة
cp discord-bot.service /etc/systemd/system/

# تعديل المسارات إذا لزم الأمر
nano /etc/systemd/system/discord-bot.service

# تحديث systemd
systemctl daemon-reload

# تفعيل البوت للتشغيل التلقائي عند إعادة تشغيل السيرفر
systemctl enable discord-bot

# تشغيل البوت
systemctl start discord-bot

# التحقق من الحالة
systemctl status discord-bot

# عرض اللوقات المباشرة
journalctl -u discord-bot -f

# إيقاف البوت
systemctl stop discord-bot

# إعادة تشغيل البوت
systemctl restart discord-bot
```

#### الخطوة 9: التحقق من عمل البوت

1. اذهب إلى سيرفر Discord
2. اكتب `!help_bot` للتأكد من أن البوت يستجيب
3. جرب `!script` للحصول على سكربت

---

## 2. الاستضافة باستخدام Docker

### المتطلبات

- VPS أو جهاز يعمل بـ Linux
- Docker و Docker Compose مثبتان

### خطوات الإعداد

#### 1. تثبيت Docker

```bash
# تحديث النظام
apt update && apt upgrade -y

# تثبيت Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# تثبيت Docker Compose
apt install docker-compose -y

# التحقق من التثبيت
docker --version
docker-compose --version
```

#### 2. إعداد المشروع

```bash
cd /root/discord-bot

# إنشاء ملف .env
nano .env
```

أضف:
```
DISCORD_TOKEN=your_token_here
```

#### 3. بناء وتشغيل الحاوية

```bash
# بناء الصورة
docker-compose build

# تشغيل البوت في الخلفية
docker-compose up -d

# عرض اللوقات
docker-compose logs -f

# إيقاف البوت
docker-compose down

# إعادة تشغيل البوت
docker-compose restart
```

#### 4. إدارة الحاوية

```bash
# عرض الحاويات النشطة
docker ps

# الدخول إلى الحاوية
docker exec -it roblox-scripts-bot bash

# عرض استخدام الموارد
docker stats

# حذف الحاوية والصورة
docker-compose down --rmi all
```

---

## 3. الاستضافة على خدمات سحابية مجانية

### ⚠️ تحذير مهم

معظم الخدمات المجانية لها قيود:
- قد تتوقف بعد فترة من عدم النشاط
- موارد محدودة (CPU، RAM)
- قد تطلب بطاقة ائتمان للتحقق

---

### أ) Railway.app (موصى به)

**المميزات:**
- ✅ سهل الاستخدام
- ✅ ربط مباشر مع GitHub
- ✅ $5 رصيد مجاني شهرياً

**الخطوات:**

1. **إنشاء حساب:**
   - اذهب إلى [railway.app](https://railway.app/)
   - سجل باستخدام GitHub

2. **إنشاء مشروع جديد:**
   - اضغط "New Project"
   - اختر "Deploy from GitHub repo"
   - اختر repository البوت

3. **إضافة متغيرات البيئة:**
   - اذهب إلى "Variables"
   - أضف: `DISCORD_TOKEN=your_token`

4. **النشر:**
   - Railway سينشر البوت تلقائياً
   - يمكنك متابعة اللوقات من لوحة التحكم

---

### ب) Render.com

**المميزات:**
- ✅ مجاني للمشاريع الصغيرة
- ✅ سهل الإعداد
- ⚠️ يتوقف بعد 15 دقيقة من عدم النشاط

**الخطوات:**

1. **إنشاء حساب:**
   - اذهب إلى [render.com](https://render.com/)
   - سجل باستخدام GitHub

2. **إنشاء Web Service:**
   - اضغط "New +"
   - اختر "Web Service"
   - اربط مع GitHub repo

3. **إعدادات:**
   - **Environment:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python bot.py`

4. **متغيرات البيئة:**
   - أضف `DISCORD_TOKEN`

5. **إبقاء البوت نشطاً:**
   - استخدم [UptimeRobot](https://uptimerobot.com/) لإرسال ping كل 5 دقائق

---

### ج) Replit

**المميزات:**
- ✅ واجهة سهلة جداً
- ✅ محرر كود مدمج
- ⚠️ يتوقف بعد فترة من عدم النشاط

**الخطوات:**

1. **إنشاء Repl:**
   - اذهب إلى [replit.com](https://replit.com/)
   - أنشئ Repl جديد (Python)

2. **رفع الملفات:**
   - ارفع `bot.py` و `requirements.txt`

3. **إضافة Secrets:**
   - من القائمة الجانبية، اختر "Secrets"
   - أضف `DISCORD_TOKEN`

4. **تعديل الكود:**
   في `bot.py`، غيّر:
   ```python
   TOKEN = os.getenv('DISCORD_TOKEN')
   ```

5. **تشغيل:**
   - اضغط "Run"

6. **إبقاء البوت نشطاً:**
   - أضف Flask server بسيط
   - استخدم UptimeRobot

---

### د) Heroku (لم يعد مجانياً)

Heroku ألغى الخطة المجانية في نوفمبر 2022. الآن يبدأ من $7/شهر.

---

## 4. الاستضافة على جهازك الشخصي

### المتطلبات

- جهاز كمبيوتر يعمل 24/7
- اتصال إنترنت مستقر
- Windows، macOS، أو Linux

### الخطوات

#### على Windows:

1. **تثبيت Python:**
   - حمّل من [python.org](https://www.python.org/downloads/)
   - تأكد من تحديد "Add Python to PATH"

2. **تشغيل البوت:**
   ```cmd
   cd C:\path\to\discord-bot
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   python bot.py
   ```

3. **التشغيل التلقائي:**
   - أنشئ ملف `.bat`:
   ```batch
   @echo off
   cd C:\path\to\discord-bot
   call venv\Scripts\activate
   python bot.py
   pause
   ```
   - ضعه في مجلد Startup:
     `C:\Users\YourName\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup`

#### على macOS/Linux:

1. **استخدام start.sh:**
   ```bash
   cd /path/to/discord-bot
   ./start.sh
   ```

2. **التشغيل التلقائي (macOS):**
   - أنشئ LaunchAgent

3. **التشغيل التلقائي (Linux):**
   - استخدم systemd كما في قسم VPS

---

## 🔧 نصائح للصيانة

### مراقبة البوت

```bash
# على VPS مع systemd
journalctl -u discord-bot -f

# على Docker
docker-compose logs -f

# على screen
screen -r discord-bot
```

### تحديث البوت

```bash
# إيقاف البوت
systemctl stop discord-bot  # أو docker-compose down

# جلب التحديثات
git pull origin main

# تحديث المكتبات
source venv/bin/activate
pip install -r requirements.txt --upgrade

# إعادة التشغيل
systemctl start discord-bot  # أو docker-compose up -d
```

### النسخ الاحتياطي

```bash
# نسخ احتياطي لملف .env
cp .env .env.backup

# نسخ احتياطي للمشروع كامل
tar -czf discord-bot-backup-$(date +%Y%m%d).tar.gz discord-bot/
```

---

## 🆘 حل المشاكل الشائعة

### البوت يتوقف بعد فترة

- **على VPS:** استخدم systemd بدلاً من screen
- **على خدمات مجانية:** استخدم UptimeRobot

### استهلاك عالي للذاكرة

- قلل `max_results` في `bot.py`
- أضف garbage collection

### البوت لا يستجيب

```bash
# تحقق من اللوقات
journalctl -u discord-bot -n 50

# تحقق من الاتصال بالإنترنت
ping discord.com

# أعد تشغيل البوت
systemctl restart discord-bot
```

---

## 📊 مقارنة الخيارات

| الخيار | التكلفة | السهولة | الاستقرار | التحكم |
|--------|---------|---------|-----------|--------|
| **VPS (مدفوع)** | $4-6/شهر | متوسطة | ممتاز | كامل |
| **Oracle Cloud Free** | مجاني | صعبة | جيد جداً | كامل |
| **Railway** | $5 مجاني/شهر | سهلة جداً | جيد | محدود |
| **Render** | مجاني | سهلة | متوسط | محدود |
| **Replit** | مجاني | سهلة جداً | ضعيف | محدود |
| **جهازك الشخصي** | مجاني | سهلة | يعتمد عليك | كامل |

---

## 🎯 التوصية النهائية

**للمبتدئين:** ابدأ بـ Railway أو Render  
**للاحترافيين:** استخدم VPS مع systemd  
**للميزانية المحدودة:** Oracle Cloud Free Tier  
**للتجربة:** جهازك الشخصي أو Replit

---

**حظاً موفقاً! 🚀**
