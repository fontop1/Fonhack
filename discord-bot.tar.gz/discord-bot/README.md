# 🤖 بوت ديسكورد لسكربتات Roblox

بوت ديسكورد يجلب سكربتات Roblox عشوائية من موقع [ScriptBlox](https://scriptblox.com/) ويرسلها تلقائياً في سيرفر Discord الخاص بك.

## ✨ المميزات

- 🎲 جلب سكربتات عشوائية من ScriptBlox
- 📊 عرض معلومات السكربت (الاسم، اللعبة/الماب، المشاهدات)
- 📜 عرض كود السكربت مباشرة
- ⏰ إرسال تلقائي للسكربتات كل فترة محددة
- 🎨 تصميم جميل باستخدام Discord Embeds
- 🔄 يعمل 24/7 عند استضافته

## 📋 المتطلبات

- Python 3.11 أو أحدث
- حساب Discord Developer
- خادم (VPS) للاستضافة 24/7 (اختياري)

## 🚀 التثبيت والإعداد

### 1. إنشاء بوت Discord

1. اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
2. اضغط على "New Application" وأعطه اسماً
3. اذهب إلى قسم "Bot" من القائمة الجانبية
4. اضغط على "Add Bot"
5. قم بتفعيل الخيارات التالية في "Privileged Gateway Intents":
   - ✅ MESSAGE CONTENT INTENT
   - ✅ SERVER MEMBERS INTENT
6. اضغط على "Reset Token" وانسخ التوكن (احتفظ به سرياً!)

### 2. دعوة البوت إلى السيرفر

1. اذهب إلى قسم "OAuth2" > "URL Generator"
2. اختر الصلاحيات التالية:
   - **Scopes**: `bot`
   - **Bot Permissions**: 
     - Send Messages
     - Embed Links
     - Read Message History
     - Use Slash Commands
3. انسخ الرابط المُنشأ وافتحه في المتصفح لدعوة البوت

### 3. تثبيت المكتبات

```bash
# إنشاء بيئة افتراضية (اختياري لكن موصى به)
python3 -m venv venv
source venv/bin/activate  # على Linux/Mac
# أو
venv\Scripts\activate  # على Windows

# تثبيت المكتبات المطلوبة
pip install -r requirements.txt
```

### 4. إعداد ملف .env

```bash
# انسخ ملف المثال
cp .env.example .env

# افتح ملف .env وضع التوكن الخاص بك
nano .env
```

ضع التوكن في ملف `.env`:
```
DISCORD_TOKEN=your_actual_discord_bot_token_here
```

### 5. تشغيل البوت

```bash
python bot.py
```

إذا كان كل شيء يعمل بشكل صحيح، سترى:
```
✅ البوت جاهز! تم تسجيل الدخول كـ YourBotName#1234
```

## 📖 الأوامر المتاحة

### `!script`
يجلب سكربت عشوائي من ScriptBlox ويعرضه مع المعلومات التالية:
- 🎮 اسم اللعبة/الماب
- 👁️ عدد المشاهدات
- 📜 كود السكربت
- 🖼️ صورة اللعبة

**مثال:**
```
!script
```

### `!autoscript [#channel] [interval]`
**للمسؤولين فقط** - يفعل أو يوقف الإرسال التلقائي للسكربتات

**المعاملات:**
- `#channel`: القناة التي سيتم الإرسال فيها (اختياري، افتراضياً القناة الحالية)
- `interval`: الفترة الزمنية بالثواني بين كل سكربت (اختياري، افتراضياً 3600 = ساعة واحدة)

**أمثلة:**
```
!autoscript                    # إرسال في القناة الحالية كل ساعة
!autoscript #scripts 1800      # إرسال في قناة #scripts كل 30 دقيقة
!autoscript #general 7200      # إرسال في قناة #general كل ساعتين
```

### `!help_bot`
يعرض قائمة بجميع الأوامر المتاحة

## 🌐 الاستضافة 24/7

لجعل البوت يعمل 24/7، تحتاج إلى استضافته على خادم. إليك بعض الخيارات:

### الخيار 1: استخدام VPS (موصى به)

**الخدمات المقترحة:**
- [DigitalOcean](https://www.digitalocean.com/) - $4-6/شهر
- [Linode](https://www.linode.com/) - $5/شهر
- [Vultr](https://www.vultr.com/) - $2.50-6/شهر
- [AWS EC2](https://aws.amazon.com/ec2/) - مجاني لمدة سنة (Free Tier)

**خطوات الاستضافة على VPS:**

1. **إنشاء VPS وتسجيل الدخول:**
```bash
ssh root@your_server_ip
```

2. **تثبيت المتطلبات:**
```bash
apt update && apt upgrade -y
apt install python3 python3-pip python3-venv git -y
```

3. **رفع الملفات:**
```bash
# الطريقة 1: استخدام git
git clone https://your-repo-url.git
cd your-repo-name

# الطريقة 2: استخدام scp من جهازك المحلي
scp -r /path/to/discord-bot root@your_server_ip:/root/
```

4. **إعداد البوت:**
```bash
cd discord-bot
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
nano .env  # ضع التوكن هنا
```

5. **تشغيل البوت باستخدام screen (للبقاء يعمل بعد إغلاق SSH):**
```bash
# تثبيت screen
apt install screen -y

# إنشاء جلسة screen جديدة
screen -S discord-bot

# تشغيل البوت
source venv/bin/activate
python bot.py

# للخروج من screen واترك البوت يعمل: اضغط Ctrl+A ثم D
# للعودة إلى الجلسة: screen -r discord-bot
```

6. **أو استخدام systemd (أفضل للتشغيل التلقائي):**

إنشاء ملف service:
```bash
nano /etc/systemd/system/discord-bot.service
```

محتوى الملف:
```ini
[Unit]
Description=Discord Roblox Scripts Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/discord-bot
Environment="PATH=/root/discord-bot/venv/bin"
ExecStart=/root/discord-bot/venv/bin/python /root/discord-bot/bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

تفعيل وتشغيل الخدمة:
```bash
systemctl daemon-reload
systemctl enable discord-bot
systemctl start discord-bot

# للتحقق من الحالة
systemctl status discord-bot

# لعرض اللوقات
journalctl -u discord-bot -f
```

### الخيار 2: استخدام خدمات مجانية

**⚠️ تحذير:** معظم الخدمات المجانية لها قيود وقد تتوقف بعد فترة من عدم النشاط.

1. **[Replit](https://replit.com/)** (مجاني مع قيود)
   - ارفع الملفات
   - أضف secret للتوكن
   - استخدم UptimeRobot لإبقائه نشطاً

2. **[Railway.app](https://railway.app/)** (مجاني لفترة محدودة)
   - ربط مع GitHub
   - إضافة متغيرات البيئة
   - نشر تلقائي

3. **[Heroku](https://www.heroku.com/)** (لم يعد مجانياً)

## 🔧 التخصيص

### تغيير الفترة الزمنية الافتراضية للإرسال التلقائي

في ملف `bot.py`، ابحث عن:
```python
auto_interval = 3600  # ساعة واحدة افتراضياً
```
غيّر القيمة بالثواني (مثلاً: 1800 = 30 دقيقة)

### تغيير عدد السكربتات المجلوبة

في ملف `bot.py`، ابحث عن:
```python
scripts = await self.fetch_scripts(page=random_page, max_results=50)
```
غيّر `max_results` إلى العدد المطلوب

### تخصيص شكل الرسالة

عدّل دالة `format_script_embed` في `bot.py` لتغيير شكل وألوان الرسائل

## 🐛 حل المشاكل

### البوت لا يستجيب للأوامر
- تأكد من تفعيل "MESSAGE CONTENT INTENT" في إعدادات البوت
- تأكد من أن البوت لديه صلاحيات "Send Messages" في القناة

### خطأ "DISCORD_TOKEN not found"
- تأكد من إنشاء ملف `.env` في نفس مجلد `bot.py`
- تأكد من كتابة التوكن بشكل صحيح

### البوت يتوقف بعد إغلاق Terminal
- استخدم `screen` أو `systemd` كما هو موضح في قسم الاستضافة

### خطأ في جلب السكربتات
- تحقق من اتصال الإنترنت
- تأكد من أن موقع ScriptBlox متاح

## 📝 الملاحظات

- البوت يستخدم API غير رسمي من ScriptBlox، قد يتوقف إذا تغير الموقع
- احتفظ بالتوكن سرياً ولا تشاركه مع أحد
- لا ترفع ملف `.env` إلى GitHub أو أي مكان عام

## 📄 الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام الشخصي والتعليمي.

## 🤝 المساهمة

إذا وجدت أي مشاكل أو لديك اقتراحات للتحسين، لا تتردد في فتح Issue أو Pull Request.

## 📞 الدعم

إذا واجهت أي مشاكل، يمكنك:
- فتح Issue في GitHub
- مراجعة [Discord.py Documentation](https://discordpy.readthedocs.io/)
- مراجعة [Discord Developer Portal](https://discord.com/developers/docs)

---

**صُنع بـ ❤️ للمجتمع العربي**
