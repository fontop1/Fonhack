#!/bin/bash

# سكربت تشغيل البوت

echo "🚀 جاري تشغيل بوت Discord..."

# التحقق من وجود ملف .env
if [ ! -f .env ]; then
    echo "❌ خطأ: ملف .env غير موجود!"
    echo "يرجى نسخ .env.example إلى .env وإضافة التوكن الخاص بك"
    exit 1
fi

# التحقق من وجود البيئة الافتراضية
if [ ! -d "venv" ]; then
    echo "📦 إنشاء البيئة الافتراضية..."
    python3 -m venv venv
fi

# تفعيل البيئة الافتراضية
echo "🔧 تفعيل البيئة الافتراضية..."
source venv/bin/activate

# تثبيت المكتبات
echo "📚 تثبيت المكتبات المطلوبة..."
pip install -q -r requirements.txt

# تشغيل البوت
echo "✅ تشغيل البوت..."
python bot.py
