# 🚀 دليل البدء السريع

## خطوات سريعة لتشغيل البوت في 5 دقائق

### 1️⃣ الحصول على Discord Bot Token

1. اذهب إلى https://discord.com/developers/applications
2. اضغط "New Application" وأعطه اسماً
3. من القائمة الجانبية، اختر "Bot"
4. اضغط "Add Bot"
5. فعّل "MESSAGE CONTENT INTENT"
6. اضغط "Reset Token" وانسخ التوكن (احتفظ به!)

### 2️⃣ دعوة البوت لسيرفرك

1. من القائمة الجانبية، اختر "OAuth2" > "URL Generator"
2. في **Scopes**، اختر: `bot`
3. في **Bot Permissions**، اختر:
   - Send Messages
   - Embed Links
   - Read Message History
4. انسخ الرابط من الأسفل وافتحه في المتصفح
5. اختر السيرفر وأكمل الدعوة

### 3️⃣ إعداد البوت على جهازك

```bash
# 1. فك الضغط (إذا كان مضغوطاً)
tar -xzf discord-bot.tar.gz
cd discord-bot

# 2. إنشاء ملف .env
cp .env.example .env
nano .env  # أو استخدم أي محرر نصوص

# 3. ضع التوكن في ملف .env
DISCORD_TOKEN=paste_your_token_here

# 4. تشغيل البوت
./start.sh
```

### 4️⃣ تجربة البوت

في Discord، اكتب:
```
!help_bot
```

للحصول على سكربت عشوائي:
```
!script
```

---

## 🎯 الأوامر الأساسية

| الأمر | الوصف |
|------|-------|
| `!script` | جلب سكربت عشوائي |
| `!autoscript #channel 3600` | تفعيل الإرسال التلقائي (للمسؤولين) |
| `!help_bot` | عرض المساعدة |

---

## 🌐 للاستضافة 24/7

راجع ملف `HOSTING_GUIDE.md` للتفاصيل الكاملة.

**الطريقة الأسرع:**

```bash
# على VPS
ssh root@your_server_ip
cd /root
# ارفع الملفات هنا
cd discord-bot
./start.sh
```

---

## ❓ مشاكل شائعة

**البوت لا يرد:**
- تأكد من تفعيل "MESSAGE CONTENT INTENT"
- تأكد من صلاحيات البوت في السيرفر

**خطأ في التوكن:**
- تحقق من ملف `.env`
- تأكد من عدم وجود مسافات إضافية

**البوت يتوقف:**
- استخدم `screen` أو `systemd` للتشغيل المستمر
- راجع `HOSTING_GUIDE.md`

---

## 📞 الدعم

- راجع `README.md` للتوثيق الكامل
- راجع `HOSTING_GUIDE.md` لخيارات الاستضافة
- Discord.py Docs: https://discordpy.readthedocs.io/

---

**استمتع بالبوت! 🎉**
